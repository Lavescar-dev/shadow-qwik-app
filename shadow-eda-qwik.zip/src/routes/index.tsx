import { component$ } from "@builder.io/qwik";
import type { DocumentHead } from "@builder.io/qwik-city";
import { TopBar } from "~/components/app/topbar/topbar";
import { WorkspaceBoard } from "~/components/board/workspace-board";
import { BottomDock } from "~/components/dock/bottom-dock";
import { InspectorPanel } from "~/components/inspector/inspector-panel";
import { PaletteSidebar } from "~/components/sidebar/palette-sidebar";
import { componentLibrary } from "~/data/component-library";
import { useWorkspaceApp } from "~/hooks/use-workspace-app";
import { filterComponentDefinitions } from "~/utils/filter";
import { findSelectedNode, getWorkspaceStats } from "~/utils/stats";
import styles from "./index.module.css";

export default component$(() => {
  const app = useWorkspaceApp();
  const stats = getWorkspaceStats(app.state.project);
  const selectedNode = findSelectedNode(
    app.state.project,
    app.state.ui.selectedNodeId,
  );
  const filteredLibrary = filterComponentDefinitions(
    componentLibrary,
    app.state.ui.searchQuery,
  );

  return (
    <div class={styles.page}>
      <TopBar
        project={app.state.project}
        tool={app.state.ui.tool}
        canUndo={app.history.past.length > 0}
        canRedo={app.history.future.length > 0}
        statusMessage={app.state.ui.statusMessage}
        onToolChange$={app.actions.setTool$}
        onUndo$={app.actions.undo$}
        onRedo$={app.actions.redo$}
        onClearTraces$={app.actions.clearTraces$}
        onClearBoard$={app.actions.clearBoard$}
        onImportJson$={app.actions.importProjectJson$}
        onProjectNameChange$={app.actions.updateProjectName$}
      />

      <div class={styles.mainArea}>
        <PaletteSidebar
          searchQuery={app.state.ui.searchQuery}
          definitions={filteredLibrary}
          stats={stats}
          onSearchChange$={app.actions.setSearchQuery$}
          onInstantiate$={app.actions.instantiateComponent$}
        />

        <div class={styles.workspaceColumn}>
          <WorkspaceBoard
            project={app.state.project}
            tool={app.state.ui.tool}
            activePin={app.state.ui.activePin}
            selectedNodeId={app.state.ui.selectedNodeId}
            draggingNodeId={app.state.ui.drag.nodeId}
            onCanvasPointerDown$={app.actions.cancelRouting$}
            onDeleteNode$={app.actions.destroyNode$}
            onDeleteTrace$={app.actions.deleteTrace$}
            onNodePointerDown$={app.actions.startNodeDrag$}
            onPinClick$={app.actions.handlePinClick$}
            onSelectNode$={app.actions.selectNode$}
          />

          <BottomDock
            logs={app.state.ui.logs}
            warnings={app.warnings}
            stats={stats}
            onClearLogs$={app.actions.clearLogPanel$}
          />
        </div>

        <InspectorPanel
          project={app.state.project}
          selectedNode={selectedNode}
          activePin={app.state.ui.activePin}
          warnings={app.warnings}
          stats={stats}
          onRenameNode$={app.actions.renameNode$}
          onDeleteNode$={app.actions.destroyNode$}
        />
      </div>
    </div>
  );
});

export const head: DocumentHead = {
  title: "SHADOW // Qwik EDA",
  meta: [
    {
      name: "description",
      content:
        "Modular Qwik rebuild of the SHADOW EDA workspace prototype.",
    },
  ],
};
