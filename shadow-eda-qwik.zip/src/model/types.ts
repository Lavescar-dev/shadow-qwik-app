export type PackageKind = "dip" | "breakout" | "module" | "mech";
export type ToolMode = "select" | "wire";
export type LogLevel = "info" | "warn" | "err" | "succ";

export interface ComponentDefinition {
  id: string;
  name: string;
  type: string;
  package: PackageKind;
  vcc: number;
  current: number;
  pins: number;
  price: number;
  tags?: string[];
}

export interface BoardNodeInstance extends ComponentDefinition {
  instanceId: string;
  defId: string;
  label: string;
  x: number;
  y: number;
  rotation: 0 | 90 | 180 | 270;
}

export interface PinRef {
  nodeId: string;
  pinIndex: number;
}

export interface TraceConnection {
  id: string;
  from: PinRef;
  to: PinRef;
}

export interface LogEntry {
  id: string;
  time: string;
  level: LogLevel;
  message: string;
}

export interface WorkspaceProject {
  id: string;
  name: string;
  version: number;
  createdAt: string;
  updatedAt: string;
  nodes: BoardNodeInstance[];
  traces: TraceConnection[];
}

export interface DragState {
  active: boolean;
  nodeId: string | null;
  offsetX: number;
  offsetY: number;
  startX: number;
  startY: number;
  moved: boolean;
  snapshot: WorkspaceProject | null;
}

export interface WorkspaceUiState {
  searchQuery: string;
  selectedNodeId: string | null;
  activePin: PinRef | null;
  tool: ToolMode;
  logs: LogEntry[];
  drag: DragState;
  autosaveStatus: "idle" | "saved" | "error";
  statusMessage: string;
}

export interface WorkspaceAppState {
  project: WorkspaceProject;
  ui: WorkspaceUiState;
}

export interface WorkspaceStats {
  componentCount: number;
  traceCount: number;
  totalPower: number;
  totalCost: number;
  categoryTotals: Record<string, number>;
}
