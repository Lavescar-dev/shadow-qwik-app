import { component$, type PropFunction } from "@builder.io/qwik";
import type { PinRef, ToolMode, TraceConnection, WorkspaceProject } from "~/model/types";
import { getTracePath } from "~/utils/geometry";
import { NodeCard } from "~/components/board/node-card";
import styles from "./workspace-board.module.css";

interface WorkspaceBoardProps {
  project: WorkspaceProject;
  tool: ToolMode;
  activePin: PinRef | null;
  selectedNodeId: string | null;
  draggingNodeId: string | null;
  onCanvasPointerDown$: PropFunction<() => void>;
  onDeleteNode$: PropFunction<(nodeId: string) => void>;
  onDeleteTrace$: PropFunction<(traceId: string) => void>;
  onNodePointerDown$: PropFunction<(nodeId: string, clientX: number, clientY: number) => void>;
  onPinClick$: PropFunction<(nodeId: string, pinIndex: number) => void>;
  onSelectNode$: PropFunction<(nodeId: string) => void>;
}

export const WorkspaceBoard = component$((props: WorkspaceBoardProps) => {
  return (
    <section class="page-card">
      <div class={styles.shell}>
        <div class={styles.header}>
          <div class={styles.headerInfo}>
            <div class="panel-header-label">workspace / board</div>
            <div class={styles.title}>Node-based electronics canvas</div>
            <div class={styles.subtitle}>
              Drag in select mode, route pins in wire mode, delete traces with a click.
            </div>
          </div>

          <div class={styles.shortcuts}>
            <span class="badge">
              <span class="kbd">V</span> select
            </span>
            <span class="badge">
              <span class="kbd">W</span> wire
            </span>
            <span class="badge">
              <span class="kbd">Esc</span> cancel
            </span>
            <span class="badge">
              <span class="kbd">Del</span> remove
            </span>
          </div>
        </div>

        <div
          id="workspace-board"
          class={styles.board}
          onPointerDown$={props.onCanvasPointerDown$}
        >
          <svg class={styles.boardSvg} aria-hidden="true">
            {props.project.traces.map((trace: TraceConnection) => {
              const d = getTracePath(props.project.nodes, trace);
              if (!d) {
                return null;
              }
              return (
                <path
                  key={trace.id}
                  d={d}
                  class={styles.trace}
                  onClick$={(event) => {
                    event.stopPropagation();
                    props.onDeleteTrace$(trace.id);
                  }}
                />
              );
            })}
          </svg>

          {props.project.nodes.length === 0 && (
            <div class={styles.empty}>
              <div>
                <div class={styles.emptyTitle}>Deploy hardware to sector</div>
                <div class={styles.emptyBody}>
                  Start by clicking any module in the library.
                </div>
              </div>
            </div>
          )}

          <div class={styles.boardNodes}>
            {props.project.nodes.map((node) => (
              <NodeCard
                key={node.instanceId}
                node={node}
                activePin={props.activePin}
                selected={props.selectedNodeId === node.instanceId}
                isDragging={props.draggingNodeId === node.instanceId}
                onDelete$={props.onDeleteNode$}
                onPinClick$={props.onPinClick$}
                onPointerDown$={props.onNodePointerDown$}
                onSelect$={props.onSelectNode$}
              />
            ))}
          </div>

          {props.activePin && (
            <div class={styles.routeHint}>
              Routing from {props.activePin.nodeId}[{props.activePin.pinIndex}] / mode {props.tool}
            </div>
          )}
        </div>
      </div>
    </section>
  );
});
