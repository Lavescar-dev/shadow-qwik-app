import { component$, type PropFunction } from "@builder.io/qwik";
import type { BoardNodeInstance, PinRef } from "~/model/types";
import { getNodeGeometry, getPinButtonStyle } from "~/utils/geometry";
import { cx } from "~/utils/cx";
import styles from "./node-card.module.css";

interface NodeCardProps {
  node: BoardNodeInstance;
  activePin: PinRef | null;
  selected: boolean;
  isDragging: boolean;
  onDelete$: PropFunction<(nodeId: string) => void>;
  onPinClick$: PropFunction<(nodeId: string, pinIndex: number) => void>;
  onPointerDown$: PropFunction<(nodeId: string, clientX: number, clientY: number) => void>;
  onSelect$: PropFunction<(nodeId: string) => void>;
}

export const NodeCard = component$((props: NodeCardProps) => {
  const geometry = getNodeGeometry(props.node);

  return (
    <div
      id={`node-${props.node.instanceId}`}
      class={cx(
        styles.node,
        props.selected && styles.selected,
        props.isDragging && styles.dragging,
      )}
      style={{
        left: `${props.node.x}px`,
        top: `${props.node.y}px`,
        width: `${geometry.width}px`,
        height: `${geometry.height}px`,
        zIndex: props.selected ? "30" : "20",
      }}
      onPointerDown$={(event) => {
        event.stopPropagation();
        props.onSelect$(props.node.instanceId);
        props.onPointerDown$(props.node.instanceId, event.clientX, event.clientY);
      }}
    >
      {props.selected && <div class={styles.selectedOutline} />}

      {props.node.package === "dip" && (
        <>
          <div class={styles.dipBody} />
          <div class={styles.dipNotch} />
          <div class={styles.dipLabel}>
            <div>
              <div class={styles.dipTitle}>{props.node.label}</div>
              <div class={styles.dipSubtitle}>
                {props.node.vcc}V | {props.node.current}mA
              </div>
            </div>
          </div>
        </>
      )}

      {props.node.package === "breakout" && (
        <div class={styles.breakoutBody}>
          <div class={styles.breakoutLabel}>
            <div>
              <div class={styles.breakoutTitle}>{props.node.label}</div>
              <div class={styles.breakoutSubtitle}>
                {props.node.vcc}V | {props.node.current}mA
              </div>
            </div>
          </div>
        </div>
      )}

      {props.node.package === "module" && (
        <div class={styles.moduleBody}>
          <div class={styles.moduleLabel}>
            <div class={styles.modulePanel}>
              <div class={styles.moduleTitle}>{props.node.label}</div>
              <div class={styles.moduleSubtitle}>
                {props.node.vcc}V | {props.node.current}mA max
              </div>
            </div>
          </div>
        </div>
      )}

      {props.node.package === "mech" && (
        <div class={styles.mechBody}>
          <div class={styles.mechLabel}>
            <div>
              <div class={styles.mechShaft} />
              <div class={styles.mechTitle}>{props.node.label}</div>
              <div class={styles.mechSubtitle}>
                {props.node.current}mA | {props.node.vcc}V
              </div>
            </div>
          </div>
        </div>
      )}

      <button
        class={styles.deleteButton}
        onPointerDown$={(event) => event.stopPropagation()}
        onClick$={(event) => {
          event.stopPropagation();
          props.onDelete$(props.node.instanceId);
        }}
      >
        x
      </button>

      {geometry.anchors.map((anchor) => {
        const isActive =
          props.activePin?.nodeId === props.node.instanceId &&
          props.activePin.pinIndex === anchor.index;

        return (
          <button
            key={`${props.node.instanceId}_${anchor.index}`}
            class={cx(styles.pin, isActive && styles.pinActive)}
            style={getPinButtonStyle(anchor.cx, anchor.cy)}
            title={`Pin ${anchor.index}`}
            onPointerDown$={(event) => event.stopPropagation()}
            onClick$={(event) => {
              event.stopPropagation();
              props.onPinClick$(props.node.instanceId, anchor.index);
            }}
          >
            <span class={styles.pinInner} />
          </button>
        );
      })}
    </div>
  );
});
