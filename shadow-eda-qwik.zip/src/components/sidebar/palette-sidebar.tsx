import { component$, type PropFunction } from "@builder.io/qwik";
import type { ComponentDefinition, WorkspaceStats } from "~/model/types";
import { groupComponentDefinitions } from "~/utils/filter";
import styles from "./palette-sidebar.module.css";

interface PaletteSidebarProps {
  searchQuery: string;
  definitions: ComponentDefinition[];
  stats: WorkspaceStats;
  onSearchChange$: PropFunction<(value: string) => void>;
  onInstantiate$: PropFunction<(definitionId: string) => void>;
}

export const PaletteSidebar = component$((props: PaletteSidebarProps) => {
  const groups = groupComponentDefinitions(props.definitions);

  return (
    <aside class="page-card">
      <div class={styles.panel}>
        <div class={styles.header}>
          <div class={styles.searchRow}>
            <span class="panel-header-label">/sys/components</span>
            <span class="badge">click to deploy</span>
          </div>

          <input
            class={styles.search}
            type="text"
            value={props.searchQuery}
            placeholder="search modules..."
            onInput$={(event) =>
              props.onSearchChange$((event.target as HTMLInputElement).value)
            }
          />

          <div class={styles.metaGrid}>
            <div class={styles.metaCard}>
              <div class={styles.metaLabel}>components</div>
              <div class={styles.metaValue}>{props.stats.componentCount}</div>
            </div>
            <div class={styles.metaCard}>
              <div class={styles.metaLabel}>traces</div>
              <div class={styles.metaValue}>{props.stats.traceCount}</div>
            </div>
            <div class={styles.metaCard}>
              <div class={styles.metaLabel}>power</div>
              <div class={styles.metaValue}>{props.stats.totalPower}mA</div>
            </div>
            <div class={styles.metaCard}>
              <div class={styles.metaLabel}>bom</div>
              <div class={styles.metaValue}>${props.stats.totalCost.toFixed(2)}</div>
            </div>
          </div>
        </div>

        <div class={styles.scroller}>
          {groups.length === 0 ? (
            <div class={styles.empty}>No modules match the current filter.</div>
          ) : (
            groups.map((group) => (
              <section class={styles.group} key={group.label}>
                <div class={styles.groupHeader}>
                  <span>{group.label}</span>
                  <span>[{group.items.length}]</span>
                </div>

                {group.items.map((item) => (
                  <button
                    key={item.id}
                    class={styles.card}
                    onClick$={() => props.onInstantiate$(item.id)}
                  >
                    <div class={styles.cardTop}>
                      <div class={styles.cardName}>{item.name}</div>
                      <div class={styles.chip}>{item.package}</div>
                    </div>
                    <div class={styles.cardMeta}>
                      <span>{item.pins} pins</span>
                      <span>{item.vcc}V</span>
                      <span>{item.current}mA</span>
                      <span>${item.price.toFixed(2)}</span>
                    </div>
                  </button>
                ))}
              </section>
            ))
          )}
        </div>
      </div>
    </aside>
  );
});
