import { $, component$, useSignal, type PropFunction } from "@builder.io/qwik";
import type { ToolMode, WorkspaceProject } from "~/model/types";
import { downloadProjectJson } from "~/services/storage";
import { cx } from "~/utils/cx";
import styles from "./topbar.module.css";

interface TopBarProps {
  project: WorkspaceProject;
  tool: ToolMode;
  canUndo: boolean;
  canRedo: boolean;
  statusMessage: string;
  onToolChange$: PropFunction<(tool: ToolMode) => void>;
  onUndo$: PropFunction<() => void>;
  onRedo$: PropFunction<() => void>;
  onClearTraces$: PropFunction<() => void>;
  onClearBoard$: PropFunction<() => void>;
  onImportJson$: PropFunction<(rawText: string) => void>;
  onProjectNameChange$: PropFunction<(value: string) => void>;
}

export const TopBar = component$((props: TopBarProps) => {
  const inputRef = useSignal<HTMLInputElement>();

  const triggerImport$ = $(() => {
    inputRef.value?.click();
  });

  return (
    <header class={styles.bar}>
      <div class={styles.brand}>
        <div class={styles.logo}>SHADOW // QWIK</div>

        <div class={styles.projectMeta}>
          <input
            class={styles.projectName}
            value={props.project.name}
            onInput$={(event) =>
              props.onProjectNameChange$(
                (event.target as HTMLInputElement).value,
              )
            }
          />
          <div class={styles.subline}>
            <span>modular workspace</span>
            <span>version {props.project.version}</span>
            <span>{props.statusMessage}</span>
          </div>
        </div>
      </div>

      <div class={styles.controls}>
        <div class={styles.toolGroup}>
          <button
            class={cx(
              styles.button,
              props.tool === "select" && styles.buttonActive,
            )}
            onClick$={() => props.onToolChange$("select")}
          >
            Select
          </button>
          <button
            class={cx(
              styles.button,
              props.tool === "wire" && styles.buttonActive,
            )}
            onClick$={() => props.onToolChange$("wire")}
          >
            Wire
          </button>
        </div>

        <div class={styles.actionGroup}>
          <button
            class={styles.button}
            disabled={!props.canUndo}
            onClick$={props.onUndo$}
          >
            Undo
          </button>
          <button
            class={styles.button}
            disabled={!props.canRedo}
            onClick$={props.onRedo$}
          >
            Redo
          </button>
          <button
            class={styles.button}
            onClick$={() => downloadProjectJson(props.project)}
          >
            Export JSON
          </button>
          <button class={styles.button} onClick$={triggerImport$}>
            Import JSON
          </button>
          <button
            class={cx(styles.button, styles.warningButton)}
            onClick$={props.onClearTraces$}
          >
            Cut Copper
          </button>
          <button
            class={cx(styles.button, styles.dangerButton)}
            onClick$={props.onClearBoard$}
          >
            Format Board
          </button>
        </div>
      </div>

      <input
        ref={inputRef}
        hidden
        type="file"
        accept=".json,application/json"
        onChange$={async (event) => {
          const input = event.target as HTMLInputElement;
          const file = input.files?.[0];
          if (!file) {
            return;
          }
          const rawText = await file.text();
          await props.onImportJson$(rawText);
          input.value = "";
        }}
      />
    </header>
  );
});
