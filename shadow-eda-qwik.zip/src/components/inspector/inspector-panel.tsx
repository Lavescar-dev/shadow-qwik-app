import { component$, type PropFunction } from "@builder.io/qwik";
import type {
  BoardNodeInstance,
  PinRef,
  WorkspaceProject,
  WorkspaceStats,
} from "~/model/types";
import styles from "./inspector-panel.module.css";

interface InspectorPanelProps {
  project: WorkspaceProject;
  selectedNode: BoardNodeInstance | null;
  activePin: PinRef | null;
  warnings: string[];
  stats: WorkspaceStats;
  onRenameNode$: PropFunction<(nodeId: string, value: string) => void>;
  onDeleteNode$: PropFunction<(nodeId: string) => void>;
}

export const InspectorPanel = component$((props: InspectorPanelProps) => {
  return (
    <aside class="page-card">
      <div class={styles.panel}>
        <div class={styles.section}>
          <div class="panel-header-label">inspector</div>

          {props.selectedNode ? (
            <>
              <div>
                <div class={styles.fieldLabel}>label</div>
                <input
                  class={styles.input}
                  value={props.selectedNode.label}
                  onInput$={(event) =>
                    props.onRenameNode$(
                      props.selectedNode!.instanceId,
                      (event.target as HTMLInputElement).value,
                    )
                  }
                />
              </div>

              <div class={styles.grid}>
                <div class={styles.statCard}>
                  <div class={styles.fieldLabel}>type</div>
                  <div class={styles.statValue}>{props.selectedNode.type}</div>
                </div>
                <div class={styles.statCard}>
                  <div class={styles.fieldLabel}>package</div>
                  <div class={styles.statValue}>{props.selectedNode.package}</div>
                </div>
                <div class={styles.statCard}>
                  <div class={styles.fieldLabel}>position</div>
                  <div class={styles.statValue}>
                    [{props.selectedNode.x}, {props.selectedNode.y}]
                  </div>
                </div>
                <div class={styles.statCard}>
                  <div class={styles.fieldLabel}>pins</div>
                  <div class={styles.statValue}>{props.selectedNode.pins}</div>
                </div>
                <div class={styles.statCard}>
                  <div class={styles.fieldLabel}>voltage</div>
                  <div class={styles.statValue}>{props.selectedNode.vcc}V</div>
                </div>
                <div class={styles.statCard}>
                  <div class={styles.fieldLabel}>current</div>
                  <div class={styles.statValue}>{props.selectedNode.current}mA</div>
                </div>
              </div>

              <button
                class={styles.deleteButton}
                onClick$={() => props.onDeleteNode$(props.selectedNode!.instanceId)}
              >
                Remove selected node
              </button>
            </>
          ) : (
            <div class={styles.tipList}>
              <div>Select a node to inspect and rename it.</div>
              <div>Use wire mode to connect pins and build a quick netlist.</div>
              <div>Undo / redo is available from the top bar and keyboard.</div>
            </div>
          )}
        </div>

        <div class={styles.section}>
          <div class="panel-header-label">active route</div>
          {props.activePin ? (
            <div class={styles.pinMeta}>
              <div>Node: {props.activePin.nodeId}</div>
              <div>Pin: {props.activePin.pinIndex}</div>
              <div>Click another pin to complete the trace.</div>
            </div>
          ) : (
            <div class={styles.tipList}>
              <div>No active route.</div>
            </div>
          )}
        </div>

        <div class={styles.section}>
          <div class="panel-header-label">workspace summary</div>
          <div class={styles.grid}>
            <div class={styles.statCard}>
              <div class={styles.fieldLabel}>components</div>
              <div class={styles.statValue}>{props.stats.componentCount}</div>
            </div>
            <div class={styles.statCard}>
              <div class={styles.fieldLabel}>traces</div>
              <div class={styles.statValue}>{props.stats.traceCount}</div>
            </div>
            <div class={styles.statCard}>
              <div class={styles.fieldLabel}>power</div>
              <div class={styles.statValue}>{props.stats.totalPower}mA</div>
            </div>
            <div class={styles.statCard}>
              <div class={styles.fieldLabel}>bom</div>
              <div class={styles.statValue}>${props.stats.totalCost.toFixed(2)}</div>
            </div>
          </div>
        </div>

        <div class={styles.section}>
          <div class="panel-header-label">warnings</div>
          {props.warnings.length === 0 ? (
            <div class={styles.tipList}>
              <div>No immediate warnings. Keep routing.</div>
            </div>
          ) : (
            <div class={styles.warningList}>
              {props.warnings.map((warning) => (
                <div key={warning} class={styles.warning}>
                  {warning}
                </div>
              ))}
            </div>
          )}
        </div>

        <div class={styles.section}>
          <div class="panel-header-label">project</div>
          <div class={styles.tipList}>
            <div>Name: {props.project.name}</div>
            <div>Created: {props.project.createdAt}</div>
            <div>Updated: {props.project.updatedAt}</div>
          </div>
        </div>
      </div>
    </aside>
  );
});
