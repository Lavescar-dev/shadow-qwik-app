import { component$, type PropFunction } from "@builder.io/qwik";
import type { LogEntry, WorkspaceStats } from "~/model/types";
import { cx } from "~/utils/cx";
import styles from "./bottom-dock.module.css";

interface BottomDockProps {
  logs: LogEntry[];
  warnings: string[];
  stats: WorkspaceStats;
  onClearLogs$: PropFunction<() => void>;
}

export const BottomDock = component$((props: BottomDockProps) => {
  return (
    <section class="page-card">
      <div class={styles.dock}>
        <div class={styles.topRow}>
          <div class={styles.warningPanel}>
            <div class="panel-header-label">live board summary</div>

            <div class={styles.summary}>
              <div class={styles.summaryCard}>
                <div class={styles.summaryLabel}>components</div>
                <div class={styles.summaryValue}>{props.stats.componentCount}</div>
              </div>
              <div class={styles.summaryCard}>
                <div class={styles.summaryLabel}>traces</div>
                <div class={styles.summaryValue}>{props.stats.traceCount}</div>
              </div>
              <div class={styles.summaryCard}>
                <div class={styles.summaryLabel}>power</div>
                <div class={styles.summaryValue}>{props.stats.totalPower}mA</div>
              </div>
            </div>

            <div class={styles.warningList}>
              {props.warnings.length === 0 ? (
                <div class={styles.empty}>No warnings. System looks stable.</div>
              ) : (
                props.warnings.map((warning) => (
                  <div key={warning} class={styles.warningItem}>
                    {warning}
                  </div>
                ))
              )}
            </div>
          </div>

          <div class={styles.logPanel}>
            <div class={styles.logHeader}>
              <div class="panel-header-label">tty / kernel output</div>
              <button class={styles.flushButton} onClick$={props.onClearLogs$}>
                flush logs
              </button>
            </div>

            <div class={styles.logList}>
              {props.logs.length === 0 ? (
                <div class={styles.empty}>No log entries yet.</div>
              ) : (
                props.logs.map((log) => (
                  <div key={log.id} class={styles.logItem}>
                    <span class={styles.time}>[{log.time}]</span>
                    <span
                      class={cx(
                        styles.level,
                        styles[`level_${log.level}` as keyof typeof styles],
                      )}
                    >
                      {log.level}
                    </span>
                    <span>{log.message}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});
