import type {
  BoardNodeInstance,
  WorkspaceProject,
  WorkspaceStats,
} from "~/model/types";

export const getWorkspaceStats = (
  project: WorkspaceProject,
): WorkspaceStats => {
  const categoryTotals = project.nodes.reduce<Record<string, number>>(
    (acc, node) => {
      acc[node.type] = (acc[node.type] ?? 0) + 1;
      return acc;
    },
    {},
  );

  const totalPower = project.nodes.reduce((sum, node) => sum + node.current, 0);
  const totalCost = project.nodes.reduce((sum, node) => sum + node.price, 0);

  return {
    componentCount: project.nodes.length,
    traceCount: project.traces.length,
    totalPower,
    totalCost,
    categoryTotals,
  };
};

export const getWorkspaceWarnings = (project: WorkspaceProject) => {
  const warnings: string[] = [];
  const stats = getWorkspaceStats(project);
  const hasPower = project.nodes.some((node) => node.type === "Power");
  const hasDriver = project.nodes.some((node) =>
    ["L293D Driver", "5V Relay Mod"].includes(node.name),
  );
  const hasActuator = project.nodes.some((node) => node.type === "Actuator");

  if (project.nodes.length > 0 && !hasPower) {
    warnings.push("No dedicated power stage is on the board yet.");
  }

  if (stats.totalPower > 2000) {
    warnings.push("Estimated power draw is above 2000mA.");
  }

  if (project.nodes.length > 1 && project.traces.length === 0) {
    warnings.push("Components are placed but no routes exist.");
  }

  if (hasActuator && !hasDriver) {
    warnings.push("Actuators are present without a visible driver stage.");
  }

  return warnings;
};

export const findSelectedNode = (
  project: WorkspaceProject,
  selectedNodeId: string | null,
): BoardNodeInstance | null =>
  project.nodes.find((node) => node.instanceId === selectedNodeId) ?? null;
