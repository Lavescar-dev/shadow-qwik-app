import type { ComponentDefinition } from "~/model/types";

export const filterComponentDefinitions = (
  definitions: ComponentDefinition[],
  query: string,
) => {
  const normalized = query.trim().toLowerCase();
  if (!normalized) {
    return definitions;
  }

  return definitions.filter((item) => {
    const haystack = [item.name, item.type, item.package, ...(item.tags ?? [])]
      .join(" ")
      .toLowerCase();
    return haystack.includes(normalized);
  });
};

export const groupComponentDefinitions = (
  definitions: ComponentDefinition[],
): Array<{ label: string; items: ComponentDefinition[] }> => {
  const groups = new Map<string, ComponentDefinition[]>();

  for (const item of definitions) {
    if (!groups.has(item.type)) {
      groups.set(item.type, []);
    }
    groups.get(item.type)?.push(item);
  }

  return [...groups.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([label, items]) => ({ label, items }));
};
