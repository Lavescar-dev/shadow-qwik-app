import type { BoardNodeInstance, TraceConnection } from "~/model/types";
import { snap } from "~/services/project";

export interface PinAnchor {
  index: number;
  cx: number;
  cy: number;
  side: "left" | "right" | "bottom";
}

export interface NodeGeometry {
  width: number;
  height: number;
  anchors: PinAnchor[];
}

const PIN_SIZE = 24;

const distribute = (count: number, start: number, end: number) => {
  if (count <= 1) {
    return [Math.round((start + end) / 2)];
  }
  const gap = (end - start) / (count - 1);
  return Array.from({ length: count }, (_, index) => start + gap * index);
};

export const getNodeGeometry = (node: BoardNodeInstance): NodeGeometry => {
  if (node.package === "dip") {
    const leftCount = Math.ceil(node.pins / 2);
    const rightCount = node.pins - leftCount;
    const height = Math.max(140, leftCount * 22 + 34);
    const width = 172;
    const leftYs = distribute(leftCount, 22, height - 22);
    const rightYs = distribute(Math.max(rightCount, 1), 22, height - 22);
    const anchors: PinAnchor[] = [];

    leftYs.forEach((cy, index) => {
      anchors.push({ index, cx: 12, cy, side: "left" });
    });

    for (let index = 0; index < rightCount; index += 1) {
      anchors.push({
        index: leftCount + index,
        cx: width - 12,
        cy: rightYs[index],
        side: "right",
      });
    }

    return { width, height, anchors };
  }

  if (node.package === "breakout") {
    const width = Math.max(168, node.pins * 22 + 40);
    const height = 118;
    const xs = distribute(node.pins, 20, width - 20);
    return {
      width,
      height,
      anchors: xs.map((cx, index) => ({
        index,
        cx,
        cy: height - 12,
        side: "bottom",
      })),
    };
  }

  if (node.package === "module") {
    const leftCount = Math.floor(node.pins / 2);
    const rightCount = node.pins - leftCount;
    const width = 204;
    const height = Math.max(92, Math.max(leftCount, rightCount) * 24 + 28);
    const leftYs = distribute(Math.max(leftCount, 1), 24, height - 24);
    const rightYs = distribute(Math.max(rightCount, 1), 24, height - 24);
    const anchors: PinAnchor[] = [];

    for (let index = 0; index < leftCount; index += 1) {
      anchors.push({ index, cx: 12, cy: leftYs[index], side: "left" });
    }

    for (let index = 0; index < rightCount; index += 1) {
      anchors.push({
        index: leftCount + index,
        cx: width - 12,
        cy: rightYs[index],
        side: "right",
      });
    }

    return { width, height, anchors };
  }

  const width = Math.max(144, node.pins * 28 + 24);
  const height = 140;
  const xs = distribute(node.pins, 24, width - 24);
  return {
    width,
    height,
    anchors: xs.map((cx, index) => ({
      index,
      cx,
      cy: height - 12,
      side: "bottom",
    })),
  };
};

export const getNodeBounds = (node: BoardNodeInstance) => {
  const geometry = getNodeGeometry(node);
  return {
    left: node.x,
    top: node.y,
    right: node.x + geometry.width,
    bottom: node.y + geometry.height,
    width: geometry.width,
    height: geometry.height,
  };
};

export const clampNodePosition = (
  node: BoardNodeInstance,
  rawX: number,
  rawY: number,
  boardWidth: number,
  boardHeight: number,
) => {
  const geometry = getNodeGeometry(node);
  const maxX = Math.max(0, boardWidth - geometry.width);
  const maxY = Math.max(0, boardHeight - geometry.height);

  return {
    x: Math.min(maxX, Math.max(0, snap(rawX))),
    y: Math.min(maxY, Math.max(0, snap(rawY))),
  };
};

export const getPinAnchorPosition = (
  nodes: BoardNodeInstance[],
  nodeId: string,
  pinIndex: number,
) => {
  const node = nodes.find((entry) => entry.instanceId === nodeId);
  if (!node) {
    return null;
  }
  const geometry = getNodeGeometry(node);
  const anchor = geometry.anchors.find((item) => item.index === pinIndex);
  if (!anchor) {
    return null;
  }

  return {
    x: node.x + anchor.cx,
    y: node.y + anchor.cy,
  };
};

export const getTracePath = (
  nodes: BoardNodeInstance[],
  trace: TraceConnection,
) => {
  const from = getPinAnchorPosition(
    nodes,
    trace.from.nodeId,
    trace.from.pinIndex,
  );
  const to = getPinAnchorPosition(nodes, trace.to.nodeId, trace.to.pinIndex);

  if (!from || !to) {
    return "";
  }

  const direction = to.x >= from.x ? 1 : -1;
  const control = Math.max(48, Math.min(180, Math.abs(to.x - from.x) * 0.45));

  return `M ${from.x} ${from.y} C ${from.x + control * direction} ${from.y}, ${to.x - control * direction} ${to.y}, ${to.x} ${to.y}`;
};

export const getPinButtonStyle = (cx: number, cy: number) => ({
  left: `${cx - PIN_SIZE / 2}px`,
  top: `${cy - PIN_SIZE / 2}px`,
  width: `${PIN_SIZE}px`,
  height: `${PIN_SIZE}px`,
});
