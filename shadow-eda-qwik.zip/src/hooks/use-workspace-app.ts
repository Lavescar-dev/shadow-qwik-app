import { $, useOnDocument, useStore, useVisibleTask$ } from "@builder.io/qwik";
import { componentLibrary } from "~/data/component-library";
import type { WorkspaceAppState } from "~/model/types";
import {
  commitHistory,
  createHistoryState,
  redoHistory,
  undoHistory,
} from "~/services/history";
import { appendLog, clearLogs } from "~/services/logger";
import {
  cloneProject,
  createEmptyProject,
  createNodeInstance,
  createTrace,
  getSafeSpawnCoord,
  touchProject,
} from "~/services/project";
import {
  clearStoredProject,
  loadStoredProject,
  parseImportedProject,
  saveStoredProject,
} from "~/services/storage";
import { clampNodePosition, getNodeBounds } from "~/utils/geometry";
import { getWorkspaceWarnings } from "~/utils/stats";

const isEditableTarget = (event: KeyboardEvent) => {
  const target = event.target as HTMLElement | null;
  if (!target) {
    return false;
  }
  const tag = target.tagName;
  return (
    tag === "INPUT" ||
    tag === "TEXTAREA" ||
    target.isContentEditable
  );
};

export const useWorkspaceApp = () => {
  const state = useStore<WorkspaceAppState>({
    project: createEmptyProject(),
    ui: {
      searchQuery: "",
      selectedNodeId: null,
      activePin: null,
      tool: "select",
      logs: [],
      drag: {
        active: false,
        nodeId: null,
        offsetX: 0,
        offsetY: 0,
        startX: 0,
        startY: 0,
        moved: false,
        snapshot: null,
      },
      autosaveStatus: "idle",
      statusMessage: "Ready",
    },
  });

  const history = useStore(createHistoryState());

  const persistProject = () => {
    try {
      saveStoredProject(state.project);
      state.ui.autosaveStatus = "saved";
      state.ui.statusMessage = "Autosaved locally";
    } catch {
      state.ui.autosaveStatus = "error";
      state.ui.statusMessage = "Autosave failed";
      appendLog(state.ui.logs, "Autosave failed.", "err");
    }
  };

  const resetDrag = () => {
    state.ui.drag.active = false;
    state.ui.drag.nodeId = null;
    state.ui.drag.offsetX = 0;
    state.ui.drag.offsetY = 0;
    state.ui.drag.startX = 0;
    state.ui.drag.startY = 0;
    state.ui.drag.moved = false;
    state.ui.drag.snapshot = null;
  };

  const sanitizeUiAfterProjectSwap = () => {
    const selectedExists = state.project.nodes.some(
      (node) => node.instanceId === state.ui.selectedNodeId,
    );
    if (!selectedExists) {
      state.ui.selectedNodeId = null;
    }

    if (state.ui.activePin) {
      const pinExists = state.project.nodes.some(
        (node) =>
          node.instanceId === state.ui.activePin?.nodeId &&
          state.ui.activePin.pinIndex < node.pins,
      );
      if (!pinExists) {
        state.ui.activePin = null;
      }
    }

    resetDrag();
  };

  useVisibleTask$(() => {
    const stored = loadStoredProject();
    if (stored) {
      state.project = stored;
      sanitizeUiAfterProjectSwap();
      state.ui.autosaveStatus = "saved";
      state.ui.statusMessage = "Recovered autosave";
      appendLog(state.ui.logs, "Recovered autosaved project.", "succ");
    } else {
      appendLog(
        state.ui.logs,
        `Qwik workspace booted. ${componentLibrary.length} modules online.`,
        "succ",
      );
    }
  });

  const setSearchQuery$ = $((value: string) => {
    state.ui.searchQuery = value;
  });

  const setTool$ = $((tool: "select" | "wire") => {
    state.ui.tool = tool;
    state.ui.statusMessage = tool === "wire" ? "Routing mode" : "Selection mode";
  });

  const updateProjectName$ = $((value: string) => {
    const nextValue = value.trim();
    state.project.name = nextValue || "SHADOW // EDA Workspace";
    touchProject(state.project);
    persistProject();
  });

  const instantiateComponent$ = $((definitionId: string) => {
    const definition = componentLibrary.find((item) => item.id === definitionId);
    if (!definition) {
      return;
    }

    let boardWidth = 1600;
    let boardHeight = 900;
    const board = typeof document !== "undefined"
      ? document.getElementById("workspace-board")
      : null;

    if (board) {
      boardWidth = board.clientWidth;
      boardHeight = board.clientHeight;
    }

    commitHistory(history, state.project);
    const coords = getSafeSpawnCoord(
      state.project.nodes,
      definition,
      boardWidth,
      boardHeight,
    );
    const instance = createNodeInstance(definition, coords);

    state.project.nodes.push(instance);
    state.ui.selectedNodeId = instance.instanceId;
    touchProject(state.project);
    persistProject();

    appendLog(
      state.ui.logs,
      `Allocated ${definition.name} at [${coords.x}, ${coords.y}]`,
      "succ",
    );
  });

  const clearBoard$ = $(() => {
    if (state.project.nodes.length === 0 && state.project.traces.length === 0) {
      return;
    }

    commitHistory(history, state.project);
    state.project.nodes = [];
    state.project.traces = [];
    state.ui.selectedNodeId = null;
    state.ui.activePin = null;
    touchProject(state.project);
    clearStoredProject();
    persistProject();
    appendLog(state.ui.logs, "Board formatted.", "err");
  });

  const clearTraces$ = $(() => {
    if (state.project.traces.length === 0) {
      return;
    }

    commitHistory(history, state.project);
    state.project.traces = [];
    state.ui.activePin = null;
    touchProject(state.project);
    persistProject();
    appendLog(state.ui.logs, "All copper routes stripped.", "warn");
  });

  const clearLogPanel$ = $(() => {
    clearLogs(state.ui.logs);
    appendLog(state.ui.logs, "Log buffer cleared.", "info");
  });

  const selectNode$ = $((nodeId: string | null) => {
    state.ui.selectedNodeId = nodeId;
  });

  const destroyNode$ = $((nodeId: string) => {
    const index = state.project.nodes.findIndex(
      (node) => node.instanceId === nodeId,
    );
    if (index < 0) {
      return;
    }

    const node = state.project.nodes[index];
    commitHistory(history, state.project);
    state.project.nodes.splice(index, 1);
    state.project.traces = state.project.traces.filter(
      (trace) => trace.from.nodeId !== nodeId && trace.to.nodeId !== nodeId,
    );

    if (state.ui.selectedNodeId === nodeId) {
      state.ui.selectedNodeId = null;
    }
    if (state.ui.activePin?.nodeId === nodeId) {
      state.ui.activePin = null;
    }

    touchProject(state.project);
    persistProject();
    appendLog(state.ui.logs, `${node.label} removed from workspace.`, "warn");
  });

  const renameNode$ = $((nodeId: string, value: string) => {
    const node = state.project.nodes.find((entry) => entry.instanceId === nodeId);
    if (!node) {
      return;
    }
    node.label = value || node.name;
    touchProject(state.project);
    persistProject();
  });

  const cancelRouting$ = $(() => {
    const hadActivePin = Boolean(state.ui.activePin);
    state.ui.activePin = null;
    state.ui.selectedNodeId = null;
    if (hadActivePin) {
      state.ui.statusMessage = "Route cancelled";
      appendLog(state.ui.logs, "Route cancelled.", "warn");
    }
  });

  const handlePinClick$ = $((nodeId: string, pinIndex: number) => {
    const currentPin = state.ui.activePin;

    if (currentPin?.nodeId === nodeId && currentPin.pinIndex === pinIndex) {
      state.ui.activePin = null;
      appendLog(state.ui.logs, "Route aborted.", "warn");
      return;
    }

    if (!currentPin) {
      state.ui.activePin = { nodeId, pinIndex };
      state.ui.tool = "wire";
      appendLog(state.ui.logs, `Routing from ${nodeId}[${pinIndex}] ...`, "info");
      return;
    }

    if (currentPin.nodeId === nodeId) {
      state.ui.activePin = null;
      appendLog(state.ui.logs, "Internal loopback blocked.", "err");
      return;
    }

    const exists = state.project.traces.some(
      (trace) =>
        (trace.from.nodeId === currentPin.nodeId &&
          trace.from.pinIndex === currentPin.pinIndex &&
          trace.to.nodeId === nodeId &&
          trace.to.pinIndex === pinIndex) ||
        (trace.to.nodeId === currentPin.nodeId &&
          trace.to.pinIndex === currentPin.pinIndex &&
          trace.from.nodeId === nodeId &&
          trace.from.pinIndex === pinIndex),
    );

    if (exists) {
      state.ui.activePin = null;
      appendLog(state.ui.logs, "Trace already exists.", "warn");
      return;
    }

    commitHistory(history, state.project);
    state.project.traces.push(
      createTrace(currentPin, {
        nodeId,
        pinIndex,
      }),
    );
    state.ui.activePin = null;
    touchProject(state.project);
    persistProject();
    appendLog(
      state.ui.logs,
      `Trace bonded: ${currentPin.nodeId}[${currentPin.pinIndex}] -> ${nodeId}[${pinIndex}]`,
      "succ",
    );
  });

  const deleteTrace$ = $((traceId: string) => {
    const nextTraces = state.project.traces.filter((trace) => trace.id !== traceId);
    if (nextTraces.length === state.project.traces.length) {
      return;
    }
    commitHistory(history, state.project);
    state.project.traces = nextTraces;
    touchProject(state.project);
    persistProject();
    appendLog(state.ui.logs, `Trace ${traceId} cut.`, "warn");
  });

  const startNodeDrag$ = $((nodeId: string, clientX: number, clientY: number) => {
    state.ui.selectedNodeId = nodeId;
    if (state.ui.tool !== "select") {
      return;
    }

    const board = typeof document !== "undefined"
      ? document.getElementById("workspace-board")
      : null;
    const node = state.project.nodes.find((entry) => entry.instanceId === nodeId);

    if (!board || !node) {
      return;
    }

    const rect = board.getBoundingClientRect();

    state.ui.drag.active = true;
    state.ui.drag.nodeId = nodeId;
    state.ui.drag.startX = node.x;
    state.ui.drag.startY = node.y;
    state.ui.drag.offsetX = clientX - rect.left - node.x;
    state.ui.drag.offsetY = clientY - rect.top - node.y;
    state.ui.drag.moved = false;
    state.ui.drag.snapshot = cloneProject(state.project);
  });

  useOnDocument(
    "pointermove",
    $((event) => {
      const pointer = event as PointerEvent;
      if (!state.ui.drag.active || !state.ui.drag.nodeId) {
        return;
      }

      const board = document.getElementById("workspace-board");
      if (!board) {
        return;
      }

      const rect = board.getBoundingClientRect();
      const node = state.project.nodes.find(
        (entry) => entry.instanceId === state.ui.drag.nodeId,
      );

      if (!node) {
        return;
      }

      const rawX = pointer.clientX - rect.left - state.ui.drag.offsetX;
      const rawY = pointer.clientY - rect.top - state.ui.drag.offsetY;
      const nextCoords = clampNodePosition(
        node,
        rawX,
        rawY,
        rect.width,
        rect.height,
      );

      node.x = nextCoords.x;
      node.y = nextCoords.y;
      state.ui.drag.moved = true;
    }),
  );

  useOnDocument(
    "pointerup",
    $(() => {
      if (!state.ui.drag.active || !state.ui.drag.nodeId) {
        return;
      }

      const node = state.project.nodes.find(
        (entry) => entry.instanceId === state.ui.drag.nodeId,
      );

      if (!node) {
        resetDrag();
        return;
      }

      const collides = state.project.nodes.some((entry) => {
        if (entry.instanceId === node.instanceId) {
          return false;
        }
        const a = getNodeBounds(entry);
        const b = getNodeBounds(node);
        return (
          a.left < b.right - 6 &&
          a.right > b.left + 6 &&
          a.top < b.bottom - 6 &&
          a.bottom > b.top + 6
        );
      });

      if (collides) {
        node.x = state.ui.drag.startX;
        node.y = state.ui.drag.startY;
        appendLog(state.ui.logs, "Hardware overlap blocked.", "err");
        resetDrag();
        return;
      }

      const moved =
        state.ui.drag.moved &&
        (node.x !== state.ui.drag.startX || node.y !== state.ui.drag.startY);

      if (moved && state.ui.drag.snapshot) {
        history.past.push(state.ui.drag.snapshot);
        history.future = [];
        if (history.past.length > 80) {
          history.past.shift();
        }
        touchProject(state.project);
        persistProject();
        appendLog(
          state.ui.logs,
          `${node.label} moved to [${node.x}, ${node.y}]`,
          "info",
        );
      }

      resetDrag();
    }),
  );

  const undo$ = $(() => {
    const previous = undoHistory(history, state.project);
    if (!previous) {
      appendLog(state.ui.logs, "Nothing to undo.", "warn");
      return;
    }

    state.project = previous;
    sanitizeUiAfterProjectSwap();
    persistProject();
    appendLog(state.ui.logs, "Undo applied.", "succ");
  });

  const redo$ = $(() => {
    const next = redoHistory(history, state.project);
    if (!next) {
      appendLog(state.ui.logs, "Nothing to redo.", "warn");
      return;
    }

    state.project = next;
    sanitizeUiAfterProjectSwap();
    persistProject();
    appendLog(state.ui.logs, "Redo applied.", "succ");
  });

  const importProjectJson$ = $((rawText: string) => {
    const parsed = parseImportedProject(rawText);
    if (!parsed) {
      appendLog(state.ui.logs, "Import failed. Invalid project file.", "err");
      return;
    }

    commitHistory(history, state.project);
    state.project = parsed;
    sanitizeUiAfterProjectSwap();
    persistProject();
    appendLog(state.ui.logs, "Project imported from JSON.", "succ");
  });

  useOnDocument(
    "keydown",
    $((event) => {
      const keyEvent = event as KeyboardEvent;
      if (isEditableTarget(keyEvent)) {
        if (keyEvent.key === "Escape" && state.ui.activePin) {
          state.ui.activePin = null;
          appendLog(state.ui.logs, "Route cancelled.", "warn");
        }
        return;
      }

      const key = keyEvent.key.toLowerCase();

      if ((keyEvent.ctrlKey || keyEvent.metaKey) && key === "z") {
        keyEvent.preventDefault();
        if (keyEvent.shiftKey) {
          const next = redoHistory(history, state.project);
          if (next) {
            state.project = next;
            sanitizeUiAfterProjectSwap();
            persistProject();
            appendLog(state.ui.logs, "Redo applied.", "succ");
          } else {
            appendLog(state.ui.logs, "Nothing to redo.", "warn");
          }
        } else {
          const previous = undoHistory(history, state.project);
          if (previous) {
            state.project = previous;
            sanitizeUiAfterProjectSwap();
            persistProject();
            appendLog(state.ui.logs, "Undo applied.", "succ");
          } else {
            appendLog(state.ui.logs, "Nothing to undo.", "warn");
          }
        }
        return;
      }

      if (key === "escape") {
        if (state.ui.activePin) {
          state.ui.activePin = null;
          appendLog(state.ui.logs, "Route cancelled.", "warn");
          return;
        }
        state.ui.selectedNodeId = null;
        return;
      }

      if (key === "delete" && state.ui.selectedNodeId) {
        const nodeId = state.ui.selectedNodeId;
        const index = state.project.nodes.findIndex(
          (node) => node.instanceId === nodeId,
        );
        if (index >= 0) {
          const node = state.project.nodes[index];
          commitHistory(history, state.project);
          state.project.nodes.splice(index, 1);
          state.project.traces = state.project.traces.filter(
            (trace) => trace.from.nodeId !== nodeId && trace.to.nodeId !== nodeId,
          );
          state.ui.selectedNodeId = null;
          if (state.ui.activePin?.nodeId === nodeId) {
            state.ui.activePin = null;
          }
          touchProject(state.project);
          persistProject();
          appendLog(state.ui.logs, `${node.label} removed from workspace.`, "warn");
        }
        return;
      }

      if (key === "v") {
        state.ui.tool = "select";
        state.ui.statusMessage = "Selection mode";
        return;
      }

      if (key === "w") {
        state.ui.tool = "wire";
        state.ui.statusMessage = "Routing mode";
      }
    }),
  );

  return {
    state,
    history,
    warnings: getWorkspaceWarnings(state.project),
    actions: {
      cancelRouting$,
      clearBoard$,
      clearLogPanel$,
      clearTraces$,
      deleteTrace$,
      destroyNode$,
      handlePinClick$,
      importProjectJson$,
      instantiateComponent$,
      redo$,
      renameNode$,
      selectNode$,
      setSearchQuery$,
      setTool$,
      startNodeDrag$,
      undo$,
      updateProjectName$,
    },
  };
};
