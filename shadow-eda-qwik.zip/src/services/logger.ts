import type { LogEntry, LogLevel } from "~/model/types";

const MAX_LOGS = 120;

export const appendLog = (
  logs: LogEntry[],
  message: string,
  level: LogLevel = "info",
) => {
  const now = new Date();
  const entry: LogEntry = {
    id: `${now.getTime().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
    time: now.toTimeString().slice(0, 8),
    level,
    message,
  };
  logs.unshift(entry);
  if (logs.length > MAX_LOGS) {
    logs.length = MAX_LOGS;
  }
};

export const clearLogs = (logs: LogEntry[]) => {
  logs.length = 0;
};
