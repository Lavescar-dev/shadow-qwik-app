import type { WorkspaceProject } from "~/model/types";
import { normalizeProject } from "~/services/project";

export const STORAGE_KEY = "shadow-eda-qwik-autosave";

export const saveStoredProject = (project: WorkspaceProject) => {
  if (typeof window === "undefined") {
    return;
  }
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(project));
};

export const loadStoredProject = (): WorkspaceProject | null => {
  if (typeof window === "undefined") {
    return null;
  }

  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    return null;
  }

  try {
    return normalizeProject(JSON.parse(raw));
  } catch {
    return null;
  }
};

export const clearStoredProject = () => {
  if (typeof window === "undefined") {
    return;
  }
  window.localStorage.removeItem(STORAGE_KEY);
};

export const parseImportedProject = (
  rawText: string,
): WorkspaceProject | null => {
  try {
    const parsed = JSON.parse(rawText);
    return normalizeProject(parsed);
  } catch {
    return null;
  }
};

export const downloadProjectJson = (project: WorkspaceProject) => {
  if (typeof document === "undefined") {
    return;
  }
  const blob = new Blob([JSON.stringify(project, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const safeName = project.name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  link.href = url;
  link.download = `${safeName || "shadow-eda-project"}.json`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
};
