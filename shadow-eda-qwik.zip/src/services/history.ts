import type { WorkspaceProject } from "~/model/types";
import { cloneProject } from "~/services/project";

export interface HistoryState {
  past: WorkspaceProject[];
  future: WorkspaceProject[];
}

const MAX_HISTORY = 80;

export const createHistoryState = (): HistoryState => ({
  past: [],
  future: [],
});

export const commitHistory = (
  history: HistoryState,
  currentProject: WorkspaceProject,
) => {
  history.past.push(cloneProject(currentProject));
  if (history.past.length > MAX_HISTORY) {
    history.past.shift();
  }
  history.future = [];
};

export const undoHistory = (
  history: HistoryState,
  currentProject: WorkspaceProject,
): WorkspaceProject | null => {
  const previous = history.past.pop();
  if (!previous) {
    return null;
  }
  history.future.unshift(cloneProject(currentProject));
  return cloneProject(previous);
};

export const redoHistory = (
  history: HistoryState,
  currentProject: WorkspaceProject,
): WorkspaceProject | null => {
  const next = history.future.shift();
  if (!next) {
    return null;
  }
  history.past.push(cloneProject(currentProject));
  return cloneProject(next);
};
