import type {
  BoardNodeInstance,
  ComponentDefinition,
  TraceConnection,
  WorkspaceProject,
} from "~/model/types";
import { getNodeBounds } from "~/utils/geometry";

const SNAP = 20;

export const cloneProject = (project: WorkspaceProject): WorkspaceProject =>
  JSON.parse(JSON.stringify(project)) as WorkspaceProject;

export const createEmptyProject = (
  name = "SHADOW // EDA Workspace",
): WorkspaceProject => {
  const now = new Date().toISOString();
  return {
    id: createUid("project"),
    name,
    version: 1,
    createdAt: now,
    updatedAt: now,
    nodes: [],
    traces: [],
  };
};

export const touchProject = (project: WorkspaceProject) => {
  project.version += 1;
  project.updatedAt = new Date().toISOString();
};

export const createUid = (prefix: string) =>
  `${prefix}_${Math.random().toString(36).slice(2, 8)}_${Date.now().toString(36)}`;

export const createNodeInstance = (
  definition: ComponentDefinition,
  coords: { x: number; y: number },
): BoardNodeInstance => ({
  ...definition,
  instanceId: createUid("node"),
  defId: definition.id,
  label: definition.name,
  x: coords.x,
  y: coords.y,
  rotation: 0,
});

export const createTrace = (
  from: TraceConnection["from"],
  to: TraceConnection["to"],
): TraceConnection => ({
  id: createUid("trace"),
  from,
  to,
});

export const normalizeProject = (value: unknown): WorkspaceProject | null => {
  if (!value || typeof value !== "object") {
    return null;
  }
  const candidate = value as Partial<WorkspaceProject>;
  if (
    typeof candidate.name !== "string" ||
    !Array.isArray(candidate.nodes) ||
    !Array.isArray(candidate.traces)
  ) {
    return null;
  }

  const now = new Date().toISOString();
  return {
    id: typeof candidate.id === "string" ? candidate.id : createUid("project"),
    name: candidate.name,
    version: typeof candidate.version === "number" ? candidate.version : 1,
    createdAt:
      typeof candidate.createdAt === "string" ? candidate.createdAt : now,
    updatedAt:
      typeof candidate.updatedAt === "string" ? candidate.updatedAt : now,
    nodes: candidate.nodes as BoardNodeInstance[],
    traces: candidate.traces as TraceConnection[],
  };
};

export const getSafeSpawnCoord = (
  nodes: BoardNodeInstance[],
  candidateDefinition: ComponentDefinition,
  boardWidth = 1600,
  boardHeight = 900,
) => {
  const attempts = 28;
  const baseX = Math.max(60, Math.round(boardWidth * 0.2 / SNAP) * SNAP);
  const baseY = Math.max(60, Math.round(boardHeight * 0.18 / SNAP) * SNAP);
  const tempNode = createNodeInstance(candidateDefinition, { x: 0, y: 0 });

  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const col = attempt % 4;
    const row = Math.floor(attempt / 4);
    const nextX = snap(baseX + col * 180);
    const nextY = snap(baseY + row * 180);
    tempNode.x = nextX;
    tempNode.y = nextY;

    const collides = nodes.some((node) => {
      const a = getNodeBounds(node);
      const b = getNodeBounds(tempNode);
      return boundsOverlap(a, b, 18);
    });

    if (!collides) {
      return { x: nextX, y: nextY };
    }
  }

  return { x: baseX, y: baseY };
};

export const boundsOverlap = (
  a: ReturnType<typeof getNodeBounds>,
  b: ReturnType<typeof getNodeBounds>,
  margin = 0,
) =>
  a.left < b.right - margin &&
  a.right > b.left + margin &&
  a.top < b.bottom - margin &&
  a.bottom > b.top + margin;

export const snap = (value: number) => Math.round(value / SNAP) * SNAP;
