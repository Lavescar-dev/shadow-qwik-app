# SHADOW EDA on Qwik

A modular Qwik rebuild of the original single-file SHADOW EDA prototype.

## What is included

- Qwik City app scaffold
- Modular component tree
- Palette / workspace / inspector / dock layout
- Drag-and-drop board nodes
- Pin-to-pin trace routing
- Undo / redo history
- Local autosave
- JSON import / export
- Modular services, models, and utilities

## Run locally

```bash
npm install
npm start
```

## Production build

```bash
npm run build
npm run preview
```

## Project structure

```text
src/
  components/
    app/
    board/
    dock/
    inspector/
    sidebar/
  data/
  hooks/
  model/
  services/
  utils/
  routes/
```

## Notes

- This rebuild keeps the visual mood of the original prototype while restructuring it for maintainability.
- State, geometry, persistence, and history are separated into dedicated modules.
