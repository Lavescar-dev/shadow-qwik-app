import { defineConfig, type UserConfig } from "vite";
import { qwikVite } from "@builder.io/qwik/optimizer";
import { qwikCity } from "@builder.io/qwik-city/vite";
import tsconfigPaths from "vite-tsconfig-paths";
import pkg from "./package.json";

type PkgDep = Record<string, string>;
const { dependencies = {}, devDependencies = {} } = pkg as any as {
  dependencies: PkgDep;
  devDependencies: PkgDep;
  [key: string]: unknown;
};

export default defineConfig((): UserConfig => {
  errorOnDuplicatesPkgDeps(devDependencies, dependencies);

  return {
    plugins: [qwikCity(), qwikVite(), tsconfigPaths({ root: "." })],
    optimizeDeps: {
      exclude: [],
    },
    server: {
      headers: {
        "Cache-Control": "public, max-age=0",
      },
    },
    preview: {
      headers: {
        "Cache-Control": "public, max-age=600",
      },
    },
  };
});

function errorOnDuplicatesPkgDeps(
  devDeps: PkgDep,
  deps: PkgDep,
) {
  const duplicateDeps = Object.keys(devDeps).filter((dep) => deps[dep]);
  const qwikPkg = Object.keys(deps).filter((value) => /qwik/i.test(value));

  if (qwikPkg.length > 0) {
    throw new Error(`Move qwik packages ${qwikPkg.join(", ")} to devDependencies`);
  }

  if (duplicateDeps.length > 0) {
    throw new Error(
      `Duplicate dependencies found in devDependencies and dependencies: ${duplicateDeps.join(", ")}`,
    );
  }
}
