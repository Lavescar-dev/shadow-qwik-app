# SHADOW / Qwik Refactor

Bu paket, yüklediğin tek parça HTML'i modüler bir Qwik yapısına ayırılmış halde verir.

## Dosya Yapısı

- `src/routes/index.tsx` — sayfa girişi
- `src/components/shadow/` — header, nav, viewport, footer ve Three.js parçaları
- `src/data/hardware-repo.ts` — donanım verisi
- `src/lib/shadow-helpers.ts` — yardımcı fonksiyonlar
- `src/lib/shadow-theme.ts` — ortak tema ve Three.js renk sabitleri
- `src/types/shadow.ts` — tipler
- `src/global.css` — görünümü birebir korumaya odaklı global stil katmanı

## Kurulum

Var olan bir Qwik City projesine kopyalamak için:

1. `src/` altındaki dosyaları kendi projene taşı.
2. `three` bağımlılığını ekle:
   - `pnpm add three`
   - veya `npm install three`
3. Projende `src/global.css` kullanılıyorsa bu dosyayı birleştir ya da mevcut dosyanın içeriğini bununla değiştir.
4. Ana route olarak `src/routes/index.tsx` dosyasını kullan.

## Notlar

- Tema, spacing, terminal estetiği ve WebGL sahne davranışı korunmuştur.
- Three.js tarafı artık client görünür olduğunda yüklenir.
- UI durumu ve veri katmanı bileşenlerden ayrılmıştır.
- Tailwind CDN bağımlılığı kaldırılmıştır; görünüm saf CSS ile korunur.
