import { component$ } from '@builder.io/qwik';
import type { DocumentHead } from '@builder.io/qwik-city';
import { ShadowAssembler } from '../components/shadow/shadow-assembler';

export default component$(() => {
  return <ShadowAssembler />;
});

export const head: DocumentHead = {
  title: 'SHADOW // WebGL IDE Pipeline',
};
