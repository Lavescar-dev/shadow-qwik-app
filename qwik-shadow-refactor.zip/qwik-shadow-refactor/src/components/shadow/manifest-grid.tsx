import { component$, type QRL } from '@builder.io/qwik';
import type { HardwareCategoryKey, ManifestEntry } from '../../types/shadow';
import { formatUsd } from '../../lib/shadow-helpers';

interface ManifestGridProps {
  entries: ManifestEntry[];
  onRemove$: QRL<(categoryKey: HardwareCategoryKey) => void>;
}

export const ManifestGrid = component$<ManifestGridProps>((props) => {
  if (props.entries.length === 0) {
    return (
      <div class="manifest-list__empty">
        <span>Manifest boş. (EOF)</span>
      </div>
    );
  }

  return (
    <>
      {props.entries.map((entry) => (
        <article class="manifest-card" key={entry.categoryKey}>
          <div class="manifest-card__body">
            <div class="manifest-card__eyebrow">&gt;&gt; {entry.categoryKey}</div>
            <div class="manifest-card__title">{entry.item.name}</div>
          </div>

          <div class="manifest-card__actions">
            <span class="manifest-card__price">{formatUsd(entry.item.price)}</span>
            <button
              type="button"
              class="manifest-card__remove"
              onClick$={() => {
                void props.onRemove$(entry.categoryKey);
              }}
            >
              unmount
            </button>
          </div>
        </article>
      ))}
    </>
  );
});
