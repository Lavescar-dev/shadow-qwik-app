import { component$, type Signal } from '@builder.io/qwik';
import type { BuildSelectionState, HardwareCategoryKey } from '../../types/shadow';
import { InspectHud } from './inspect-hud';
import { SystemStatus } from './system-status';
import { TopologyCanvas } from './topology-canvas';

interface MainViewportProps {
  selectedIds: BuildSelectionState;
  hoveredKey: Signal<HardwareCategoryKey | null>;
  missingCount: number;
}

export const MainViewport = component$<MainViewportProps>((props) => {
  return (
    <main class="shadow-main">
      <div class="inspect-hud-shell">
        <div class="inspect-hud-shell__label">Raycaster_V7.0_Widescreen</div>
        <div id="hud-display" class="inspect-hud-shell__body">
          <InspectHud hoveredKey={props.hoveredKey} selectedIds={props.selectedIds} />
        </div>
      </div>

      <div class="viewport-state-shell">
        <SystemStatus missingCount={props.missingCount} />
      </div>

      <TopologyCanvas hoveredKey={props.hoveredKey} selectedIds={props.selectedIds} />
    </main>
  );
});
