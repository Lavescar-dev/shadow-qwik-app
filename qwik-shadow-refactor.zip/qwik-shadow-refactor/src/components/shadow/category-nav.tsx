import { component$, type QRL } from '@builder.io/qwik';
import { HARDWARE_CATEGORY_KEYS, HARDWARE_REPO } from '../../data/hardware-repo';
import type { BuildSelectionState, HardwareCategoryKey } from '../../types/shadow';
import { formatUsd } from '../../lib/shadow-helpers';

interface CategoryNavProps {
  activeCategory: HardwareCategoryKey | null;
  selectedIds: BuildSelectionState;
  onToggle$: QRL<(categoryKey: HardwareCategoryKey) => void>;
  onSelect$: QRL<(categoryKey: HardwareCategoryKey, itemId: string) => void>;
}

export const CategoryNav = component$<CategoryNavProps>((props) => {
  return (
    <nav class="shadow-nav" data-category-nav>
      <div class="shadow-nav__header">
        <div class="shadow-nav__header-dot" />
        <span class="shadow-nav__header-label">/var/lib/repo/select_node</span>
      </div>

      <div class="shadow-nav__categories" id="component-categories">
        {HARDWARE_CATEGORY_KEYS.map((categoryKey) => {
          const category = HARDWARE_REPO[categoryKey];
          const isSelected = Boolean(props.selectedIds[categoryKey]);
          const isOpen = props.activeCategory === categoryKey;

          return (
            <div class="category-node" key={categoryKey}>
              <button
                type="button"
                class={[
                  'category-node__button',
                  isSelected ? 'category-node__button--selected' : 'category-node__button--idle',
                ]}
                onClick$={(event) => {
                  event.stopPropagation();
                  void props.onToggle$(categoryKey);
                }}
              >
                <span>{category.title}</span>
                {isSelected ? <span class="category-node__dot" /> : null}
              </button>

              <div
                class={[
                  'category-node__dropdown',
                  isOpen ? 'category-node__dropdown--open' : 'category-node__dropdown--closed',
                ]}
              >
                {category.items.map((item) => {
                  const isItemActive = props.selectedIds[categoryKey] === item.id;

                  return (
                    <button
                      type="button"
                      class={[
                        'category-item',
                        isItemActive ? 'category-item--active' : 'category-item--idle',
                      ]}
                      key={item.id}
                      onClick$={() => {
                        void props.onSelect$(categoryKey, item.id);
                      }}
                    >
                      <div class="category-item__row">
                        <div class="category-item__name">{item.name}</div>
                        <div class="category-item__price">{formatUsd(item.price)}</div>
                      </div>
                      <div class="category-item__desc">{item.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </nav>
  );
});
