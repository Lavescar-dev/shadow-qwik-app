import { component$, useSignal, useVisibleTask$, type Signal } from '@builder.io/qwik';
import { HARDWARE_CATEGORY_KEYS } from '../../data/hardware-repo';
import { SHADOW_THEME } from '../../lib/shadow-theme';
import type { BuildSelectionState, HardwareCategoryKey } from '../../types/shadow';

interface TopologyCanvasProps {
  selectedIds: BuildSelectionState;
  hoveredKey: Signal<HardwareCategoryKey | null>;
}

type SchematicPart = {
  type: 'box' | 'cyl';
  args: number[];
  pos?: [number, number, number];
  rot?: [number, number, number];
};

type SchematicSchema = {
  hitbox: [number, number, number];
  hitboxPos?: [number, number, number];
  parts: SchematicPart[];
};

const SCHEMATICS: Record<HardwareCategoryKey, SchematicSchema> = {
  mobo: {
    hitbox: [14, 0.4, 18],
    hitboxPos: [0, 0, 0],
    parts: [
      { type: 'box', args: [14, 0.2, 18], pos: [0, 0, 0] },
      { type: 'box', args: [3, 0.3, 3], pos: [-2, 0.25, -4] },
      { type: 'box', args: [1.5, 1.2, 7], pos: [-6, 0.7, -4] },
      { type: 'box', args: [6, 1.2, 1.5], pos: [-2, 0.7, -8] },
      { type: 'box', args: [10, 0.8, 1], pos: [0, 0.5, 3] },
      { type: 'box', args: [10, 0.8, 1], pos: [0, 0.5, 6] },
      { type: 'box', args: [3, 1, 5], pos: [4, 0.6, -4] },
    ],
  },
  cpu: {
    hitbox: [3.5, 1, 3.5],
    hitboxPos: [0, 0, 0],
    parts: [
      { type: 'box', args: [2.5, 0.1, 2.5], pos: [0, 0, 0] },
      { type: 'box', args: [2.2, 0.3, 2.2], pos: [0, 0.2, 0] },
    ],
  },
  ram: {
    hitbox: [3, 4, 6],
    hitboxPos: [0, 2, 0],
    parts: [
      { type: 'box', args: [0.2, 3.5, 5.2], pos: [-0.6, 1.75, 0] },
      { type: 'box', args: [0.2, 3.5, 5.2], pos: [0.6, 1.75, 0] },
      { type: 'box', args: [0.6, 3.2, 5], pos: [-0.6, 1.8, 0] },
      { type: 'box', args: [0.6, 3.2, 5], pos: [0.6, 1.8, 0] },
    ],
  },
  gpu: {
    hitbox: [13, 6, 4],
    hitboxPos: [0, 3, 0],
    parts: [
      { type: 'box', args: [12, 4.5, 0.2], pos: [0, 2.25, 0] },
      { type: 'box', args: [11.8, 4.2, 1.5], pos: [0, 2.25, 0.85] },
      { type: 'cyl', args: [1.6, 1.6, 0.4, 16], pos: [-3.5, 2.25, 1.8], rot: [Math.PI / 2, 0, 0] },
      { type: 'cyl', args: [1.6, 1.6, 0.4, 16], pos: [3.5, 2.25, 1.8], rot: [Math.PI / 2, 0, 0] },
    ],
  },
  cooling: {
    hitbox: [5, 6, 5],
    hitboxPos: [0, 3, 0],
    parts: [
      { type: 'box', args: [2.5, 0.5, 2.5], pos: [0, 0.25, 0] },
      { type: 'box', args: [3, 4, 3.5], pos: [0, 2.5, 0] },
      { type: 'box', args: [1, 3.5, 3.5], pos: [2.1, 2.5, 0] },
      { type: 'box', args: [1, 3.5, 3.5], pos: [-2.1, 2.5, 0] },
    ],
  },
  storage: {
    hitbox: [4.5, 1, 2],
    hitboxPos: [0, 0.5, 0],
    parts: [
      { type: 'box', args: [3.5, 0.1, 1.2], pos: [0, 0.05, 0] },
      { type: 'box', args: [0.6, 0.15, 0.8], pos: [1.2, 0.175, 0] },
      { type: 'box', args: [1, 0.15, 1], pos: [-0.5, 0.175, 0] },
    ],
  },
  psu: {
    hitbox: [7, 5, 7],
    hitboxPos: [0, 2.5, 0],
    parts: [
      { type: 'box', args: [6, 4, 6], pos: [0, 2, 0] },
      { type: 'cyl', args: [2.5, 2.5, 0.2, 16], pos: [0, 4.1, 0] },
      { type: 'box', args: [2, 1, 1], pos: [-2, 1, -3] },
    ],
  },
  case_fans: {
    hitbox: [3, 11, 5],
    hitboxPos: [0, 0, 0],
    parts: [
      { type: 'box', args: [1.5, 4, 4], pos: [0, 2.5, 0] },
      { type: 'cyl', args: [1.8, 1.8, 1.6, 16], pos: [0, 2.5, 0], rot: [Math.PI / 2, 0, Math.PI / 2] },
      { type: 'box', args: [1.5, 4, 4], pos: [0, -2.5, 0] },
      { type: 'cyl', args: [1.8, 1.8, 1.6, 16], pos: [0, -2.5, 0], rot: [Math.PI / 2, 0, Math.PI / 2] },
    ],
  },
  chassis: {
    hitbox: [23, 2, 23],
    hitboxPos: [0, -7.5, 0],
    parts: [
      { type: 'box', args: [22, 0.5, 22], pos: [0, -7.25, 0] },
      { type: 'box', args: [22, 14, 0.5], pos: [0, 0, -10.75] },
    ],
  },
};

const NODE_POSITIONS: Record<HardwareCategoryKey, [number, number, number]> = {
  chassis: [0, 0, 0],
  mobo: [-2, -6.8, 0],
  case_fans: [10, -2, 0],
  psu: [-6, -6.8, 7],
  cpu: [-4, -6.45, -4],
  ram: [2, -6.4, -4],
  cooling: [-4, -6.15, -4],
  gpu: [-2, -6.2, 3],
  storage: [-6, -6.45, 0],
};

export const TopologyCanvas = component$<TopologyCanvasProps>((props) => {
  const hostRef = useSignal<HTMLElement>();

  useVisibleTask$(async ({ cleanup }) => {
    const container = hostRef.value;
    if (!container) {
      return;
    }

    const THREE = await import('three');
    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera();
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    const hardwareGroup = new THREE.Group();
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2(-2, -2);

    const hwMeshes = {} as Record<HardwareCategoryKey, any>;
    const raycastTargets: any[] = [];
    const d = SHADOW_THEME.viewportDepth;

    camera.position.set(25, 30, 25);
    camera.lookAt(scene.position);

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.appendChild(renderer.domElement);

    scene.add(hardwareGroup);

    const gridHelper = new THREE.GridHelper(
      40,
      40,
      SHADOW_THEME.colorsHex.termBorder,
      SHADOW_THEME.colorsHex.paneHeader,
    );
    gridHelper.position.y = -8;
    hardwareGroup.add(gridHelper);

    const createCompositeNode = (
      key: HardwareCategoryKey,
      schema: SchematicSchema,
      position: [number, number, number],
    ) => {
      const group = new THREE.Group();
      const hitGeo = new THREE.BoxGeometry(...schema.hitbox);
      const hitMat = new THREE.MeshBasicMaterial({ visible: false });
      const hitMesh = new THREE.Mesh(hitGeo, hitMat);

      if (schema.hitboxPos) {
        hitMesh.position.set(...schema.hitboxPos);
      }

      hitMesh.userData = { key };
      group.add(hitMesh);
      raycastTargets.push(hitMesh);

      schema.parts.forEach((part) => {
        const geometry =
          part.type === 'box'
            ? new THREE.BoxGeometry(...part.args)
            : new THREE.CylinderGeometry(...part.args);

        const fillMat = new THREE.MeshBasicMaterial({
          color: SHADOW_THEME.colorsHex.unmounted,
          transparent: true,
          opacity: 0.05,
          depthWrite: false,
        });
        const fillMesh = new THREE.Mesh(geometry, fillMat);

        const edges = new THREE.EdgesGeometry(geometry);
        const lineMat = new THREE.LineBasicMaterial({
          color: SHADOW_THEME.colorsHex.unmounted,
          transparent: true,
          opacity: 0.4,
        });
        const wireframe = new THREE.LineSegments(edges, lineMat);

        if (part.pos) {
          fillMesh.position.set(...part.pos);
          wireframe.position.set(...part.pos);
        }

        if (part.rot) {
          fillMesh.rotation.set(...part.rot);
          wireframe.rotation.set(...part.rot);
        }

        group.add(fillMesh);
        group.add(wireframe);
      });

      const [x, baseY, z] = position;
      const spreadOffset = HARDWARE_CATEGORY_KEYS.indexOf(key) * 4;
      const floatingY = baseY + 20 + spreadOffset;

      group.position.set(x, floatingY, z);
      group.userData = { key, baseY, floatingY, mounted: false };

      hardwareGroup.add(group);
      hwMeshes[key] = group;
    };

    HARDWARE_CATEGORY_KEYS.forEach((key) => {
      createCompositeNode(key, SCHEMATICS[key], NODE_POSITIONS[key]);
    });

    const updateCamera = () => {
      const aspect = container.clientWidth / Math.max(container.clientHeight, 1);
      camera.left = -d * aspect;
      camera.right = d * aspect;
      camera.top = d;
      camera.bottom = -d;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    updateCamera();
    const resizeObserver = new ResizeObserver(updateCamera);
    resizeObserver.observe(container);

    const onMouseMove = (event: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -(((event.clientY - rect.top) / rect.height) * 2 - 1);
    };

    const onMouseLeave = () => {
      mouse.x = -2;
      mouse.y = -2;
      props.hoveredKey.value = null;
      hoveredKey = null;
    };

    container.addEventListener('mousemove', onMouseMove);
    container.addEventListener('mouseleave', onMouseLeave);

    let hoveredKey: HardwareCategoryKey | null = null;
    let frameId = 0;

    const animate = () => {
      frameId = window.requestAnimationFrame(animate);

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(raycastTargets);

      let nextHover: HardwareCategoryKey | null = null;
      if (intersects.length > 0) {
        const hit = intersects.find((entry: any) => entry.object.userData.key !== 'chassis');
        nextHover = (hit?.object.userData.key ?? 'chassis') as HardwareCategoryKey;
      }

      if (hoveredKey !== nextHover) {
        hoveredKey = nextHover;
        props.hoveredKey.value = nextHover;
      }

      hardwareGroup.rotation.y -= SHADOW_THEME.rotationStep;

      HARDWARE_CATEGORY_KEYS.forEach((key) => {
        const group = hwMeshes[key];
        if (!group) {
          return;
        }

        const isMounted = Boolean(props.selectedIds[key]);
        const isHovered = group.userData.key === hoveredKey;

        group.userData.mounted = isMounted;
        group.position.y +=
          ((isMounted ? group.userData.baseY : group.userData.floatingY) - group.position.y) * 0.12;

        let targetOpacityWireframe = isMounted ? 1.0 : 0.3;
        let targetOpacityFill = isMounted ? 0.15 : 0.02;
        let targetColor = new THREE.Color(
          isMounted ? SHADOW_THEME.colorsHex.mounted : SHADOW_THEME.colorsHex.unmounted,
        );

        if (isHovered) {
          targetOpacityWireframe = 1.0;
          targetOpacityFill = 0.9;
          targetColor = new THREE.Color(SHADOW_THEME.colorsHex.hover);
        }

        group.traverse((child: any) => {
          if (child instanceof THREE.LineSegments) {
            child.material.opacity += (targetOpacityWireframe - child.material.opacity) * 0.2;
            child.material.color.lerp(targetColor, 0.2);
            return;
          }

          if (child instanceof THREE.Mesh && child.material?.visible !== false) {
            child.material.opacity += (targetOpacityFill - child.material.opacity) * 0.2;
            child.material.color.lerp(targetColor, 0.2);
          }
        });
      });

      renderer.render(scene, camera);
    };

    animate();

    cleanup(() => {
      window.cancelAnimationFrame(frameId);
      props.hoveredKey.value = null;
      resizeObserver.disconnect();
      container.removeEventListener('mousemove', onMouseMove);
      container.removeEventListener('mouseleave', onMouseLeave);

      hardwareGroup.traverse((child: any) => {
        child.geometry?.dispose?.();

        if (Array.isArray(child.material)) {
          child.material.forEach((material: any) => material?.dispose?.());
        } else {
          child.material?.dispose?.();
        }
      });

      renderer.dispose();
      container.innerHTML = '';
    });
  });

  return <div id="topo-container" ref={hostRef} class="topo-container" />;
});
