import { component$, type QRL } from '@builder.io/qwik';
import { formatUsd } from '../../lib/shadow-helpers';
import type { HardwareCategoryKey, ManifestEntry, StatusKind } from '../../types/shadow';
import { ManifestGrid } from './manifest-grid';

interface BuildFooterProps {
  entries: ManifestEntry[];
  totalCost: number;
  statusMessage: string;
  statusType: StatusKind;
  onCompile$: QRL<() => void>;
  onRemove$: QRL<(categoryKey: HardwareCategoryKey) => void>;
}

const statusClassMap: Record<StatusKind, string> = {
  idle: 'build-status--idle',
  info: 'build-status--info',
  warn: 'build-status--warn',
  error: 'build-status--error',
  success: 'build-status--success',
};

export const BuildFooter = component$<BuildFooterProps>((props) => {
  return (
    <footer class="build-footer">
      <div class="build-footer__manifest-panel">
        <div class="build-footer__panel-header">
          <span class="build-footer__panel-title">/etc/build_manifest.conf</span>
          <span class="build-footer__panel-user">root@shadow</span>
        </div>

        <div id="manifest-list" class="manifest-list">
          <ManifestGrid entries={props.entries} onRemove$={props.onRemove$} />
        </div>
      </div>

      <aside class="build-footer__capex-panel">
        <div>
          <span class="build-footer__capex-label">Total Allocated CAPEX</span>
          <span id="build-total" class="build-footer__capex-value">
            {formatUsd(props.totalCost)}
          </span>
        </div>

        <div class="build-footer__compile-block">
          <button
            type="button"
            class="build-footer__compile-button"
            onClick$={() => {
              void props.onCompile$();
            }}
          >
            ./make_install
          </button>

          <div id="build-status" class={['build-status', statusClassMap[props.statusType]]}>
            {props.statusMessage}
          </div>
        </div>
      </aside>
    </footer>
  );
});
