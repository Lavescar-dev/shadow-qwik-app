import { component$, useSignal, useVisibleTask$ } from '@builder.io/qwik';

const formatDuration = (seconds: number): string => {
  const hours = String(Math.floor(seconds / 3600)).padStart(2, '0');
  const minutes = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
  const remainder = String(seconds % 60).padStart(2, '0');

  return `${hours}:${minutes}:${remainder}`;
};

export const UptimeClock = component$(() => {
  const uptime = useSignal(0);

  useVisibleTask$(({ cleanup }) => {
    const intervalId = window.setInterval(() => {
      uptime.value += 1;
    }, 1000);

    cleanup(() => {
      window.clearInterval(intervalId);
    });
  });

  return <span id="uptime-clock">{formatDuration(uptime.value)}</span>;
});
