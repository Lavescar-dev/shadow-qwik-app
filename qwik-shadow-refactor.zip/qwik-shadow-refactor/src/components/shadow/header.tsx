import { component$ } from '@builder.io/qwik';
import { UptimeClock } from './uptime-clock';

export const ShadowHeader = component$(() => {
  return (
    <header class="shadow-header">
      <div>
        <h1 class="shadow-header__title">
          Build.sh <span class="shadow-header__subtitle">// TMUX Pipeline Layout</span>
        </h1>
      </div>

      <div class="shadow-header__uptime">
        <div class="shadow-header__uptime-label">Kernel Uptime</div>
        <div class="shadow-header__uptime-value">
          <UptimeClock />
        </div>
      </div>
    </header>
  );
});
