import { component$ } from '@builder.io/qwik';

interface SystemStatusProps {
  missingCount: number;
}

export const SystemStatus = component$<SystemStatusProps>(({ missingCount }) => {
  const isReady = missingCount === 0;

  return (
    <>
      <div class="viewport-state__label">SYS_STATE</div>
      <div
        id="hud-status"
        class={[
          'viewport-state__value',
          isReady ? 'viewport-state__value--ready' : 'viewport-state__value--warn',
        ]}
      >
        {isReady ? 'READY' : `MISSING (${missingCount})`}
      </div>
    </>
  );
});
