import { component$, type Signal } from '@builder.io/qwik';
import { HARDWARE_REPO } from '../../data/hardware-repo';
import { getSelectedItem } from '../../lib/shadow-helpers';
import type { BuildSelectionState, HardwareCategoryKey } from '../../types/shadow';

interface InspectHudProps {
  hoveredKey: Signal<HardwareCategoryKey | null>;
  selectedIds: BuildSelectionState;
}

export const InspectHud = component$<InspectHudProps>(({ hoveredKey, selectedIds }) => {
  const currentKey = hoveredKey.value;

  if (!currentKey) {
    return <div class="inspect-hud__placeholder">&gt; Awaiting interrupt...</div>;
  }

  const selectedItem = getSelectedItem(selectedIds, currentKey);

  if (selectedItem) {
    return (
      <>
        <div class="inspect-hud__title">{selectedItem.name}</div>
        <div class="inspect-hud__desc">{selectedItem.desc}</div>

        <div class="inspect-hud__row inspect-hud__row--top">
          <span class="inspect-hud__label">ADDR:</span>
          <span class="inspect-hud__value">0x{selectedItem.id.toUpperCase().substring(0, 8)}</span>
        </div>

        <div class="inspect-hud__row">
          <span class="inspect-hud__label">STAT:</span>
          <span class="inspect-hud__pill inspect-hud__pill--mounted">MOUNTED</span>
        </div>
      </>
    );
  }

  return (
    <>
      <div class="inspect-hud__title">{HARDWARE_REPO[currentKey].title}</div>
      <div class="inspect-hud__pill inspect-hud__pill--warning">[ NULL_PTR ]</div>
      <div class="inspect-hud__desc inspect-hud__desc--unallocated">Status: Unallocated</div>
    </>
  );
});
