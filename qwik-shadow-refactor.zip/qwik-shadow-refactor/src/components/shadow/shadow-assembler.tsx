import {
  $,
  component$,
  useComputed$,
  useOnDocument,
  useSignal,
  useStore,
} from '@builder.io/qwik';
import {
  createInitialBuildState,
  getManifestEntries,
  getMissingCount,
  getTotalCost,
} from '../../lib/shadow-helpers';
import type { HardwareCategoryKey, StatusKind } from '../../types/shadow';
import { BuildFooter } from './build-footer';
import { CategoryNav } from './category-nav';
import { ShadowHeader } from './header';
import { MainViewport } from './main-viewport';

interface UiState {
  activeCategory: HardwareCategoryKey | null;
  statusMessage: string;
  statusType: StatusKind;
}

export const ShadowAssembler = component$(() => {
  const buildState = useStore(createInitialBuildState(), { deep: false });
  const ui = useStore<UiState>({
    activeCategory: null,
    statusMessage: 'Idle',
    statusType: 'idle',
  });
  const hoveredKey = useSignal<HardwareCategoryKey | null>(null);
  const statusTimerToken = useSignal(0);

  const manifestEntries = useComputed$(() => getManifestEntries(buildState));
  const totalCost = useComputed$(() => getTotalCost(manifestEntries.value));
  const missingCount = useComputed$(() => getMissingCount(buildState));

  const flashStatus = $((message: string, type: StatusKind = 'info') => {
    ui.statusMessage = message;
    ui.statusType = type;

    const currentToken = ++statusTimerToken.value;
    window.setTimeout(() => {
      if (statusTimerToken.value !== currentToken) {
        return;
      }

      ui.statusMessage = 'Idle';
      ui.statusType = 'idle';
    }, 3000);
  });

  const toggleCategory = $((categoryKey: HardwareCategoryKey) => {
    ui.activeCategory = ui.activeCategory === categoryKey ? null : categoryKey;
  });

  const selectComponent = $((categoryKey: HardwareCategoryKey, itemId: string) => {
    buildState[categoryKey] = itemId;
    ui.activeCategory = null;
    void flashStatus(`[ALLOC] /mnt/${categoryKey} mapped.`, 'info');
  });

  const removeComponent = $((categoryKey: HardwareCategoryKey) => {
    buildState[categoryKey] = null;
    void flashStatus(`[WARN] /mnt/${categoryKey} unmounted.`, 'warn');
  });

  const compileBuild = $(() => {
    const unresolvedCount = missingCount.value;

    if (unresolvedCount > 0) {
      void flashStatus(`FATAL: Eksik dependency [${unresolvedCount}].`, 'error');
      return;
    }

    void flashStatus('SUCCESS: Kernel update tamamlandı.', 'success');
  });

  useOnDocument(
    'click',
    $((event) => {
      const target = event.target as Element | null;
      if (!target?.closest?.('[data-category-nav]')) {
        ui.activeCategory = null;
      }
    }),
  );

  return (
    <section class="shadow-page">
      <div class="shadow-grid-bg" />

      <ShadowHeader />

      <CategoryNav
        activeCategory={ui.activeCategory}
        selectedIds={buildState}
        onToggle$={toggleCategory}
        onSelect$={selectComponent}
      />

      <MainViewport
        hoveredKey={hoveredKey}
        selectedIds={buildState}
        missingCount={missingCount.value}
      />

      <BuildFooter
        entries={manifestEntries.value}
        totalCost={totalCost.value}
        statusMessage={ui.statusMessage}
        statusType={ui.statusType}
        onCompile$={compileBuild}
        onRemove$={removeComponent}
      />
    </section>
  );
});
