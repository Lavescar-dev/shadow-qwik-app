export type HardwareCategoryKey =
  | 'chassis'
  | 'case_fans'
  | 'psu'
  | 'mobo'
  | 'cpu'
  | 'ram'
  | 'storage'
  | 'gpu'
  | 'cooling';

export interface HardwareItem {
  id: string;
  name: string;
  desc: string;
  price: number;
}

export interface HardwareCategory {
  title: string;
  items: HardwareItem[];
}

export type HardwareRepo = Record<HardwareCategoryKey, HardwareCategory>;
export type BuildSelectionState = Record<HardwareCategoryKey, string | null>;

export type StatusKind = 'idle' | 'info' | 'warn' | 'error' | 'success';

export interface ManifestEntry {
  categoryKey: HardwareCategoryKey;
  item: HardwareItem;
}
