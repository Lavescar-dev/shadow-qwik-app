import { HARDWARE_CATEGORY_KEYS, HARDWARE_REPO } from '../data/hardware-repo';
import type {
  BuildSelectionState,
  HardwareCategoryKey,
  HardwareItem,
  ManifestEntry,
} from '../types/shadow';

const usdFormatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

export const createInitialBuildState = (): BuildSelectionState => ({
  chassis: null,
  case_fans: null,
  psu: null,
  mobo: null,
  cpu: null,
  ram: null,
  storage: null,
  gpu: null,
  cooling: null,
});

export const findHardwareItem = (
  categoryKey: HardwareCategoryKey,
  itemId: string | null,
): HardwareItem | null => {
  if (!itemId) {
    return null;
  }

  return HARDWARE_REPO[categoryKey].items.find((item) => item.id === itemId) ?? null;
};

export const getSelectedItem = (
  state: BuildSelectionState,
  categoryKey: HardwareCategoryKey,
): HardwareItem | null => findHardwareItem(categoryKey, state[categoryKey]);

export const getManifestEntries = (state: BuildSelectionState): ManifestEntry[] =>
  HARDWARE_CATEGORY_KEYS.flatMap((categoryKey) => {
    const item = getSelectedItem(state, categoryKey);
    return item ? [{ categoryKey, item }] : [];
  });

export const getTotalCost = (entries: ManifestEntry[]): number =>
  entries.reduce((sum, entry) => sum + entry.item.price, 0);

export const getMissingCount = (state: BuildSelectionState): number =>
  HARDWARE_CATEGORY_KEYS.filter((categoryKey) => !state[categoryKey]).length;

export const formatUsd = (value: number): string => usdFormatter.format(value);
