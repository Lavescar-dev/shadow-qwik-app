export const SHADOW_THEME = {
  gridSize: 30,
  viewportDepth: 16,
  rotationStep: 0.002,
  colors: {
    termBg: '#020202',
    termFg: '#e5e5e5',
    termAccent: '#00ffcc',
    termDim: '#1a1a1a',
    termBorder: '#1f1f1f',
    panelBg: '#050505',
    paneHeader: '#0a0a0a',
    unmounted: '#333333',
    hover: '#ffffff',
  },
  colorsHex: {
    termBorder: 0x1f1f1f,
    paneHeader: 0x0a0a0a,
    mounted: 0x00ffcc,
    unmounted: 0x333333,
    hover: 0xffffff,
  },
} as const;
