import type { HardwareCategoryKey, HardwareRepo } from '../types/shadow';

export const HARDWARE_CATEGORY_KEYS: HardwareCategoryKey[] = [
  'chassis',
  'case_fans',
  'psu',
  'mobo',
  'cpu',
  'ram',
  'storage',
  'gpu',
  'cooling',
];

export const HARDWARE_REPO: HardwareRepo = {
  chassis: {
    title: 'CHASSIS',
    items: [
      { id: 'case_nor', name: 'Fractal North', desc: 'Workstation kasası.', price: 139.0 },
      { id: 'case_rack', name: 'Sliger 4U', desc: '19-inch kabin.', price: 299.0 },
    ],
  },
  case_fans: {
    title: 'CASE FANS',
    items: [
      { id: 'fan_arc', name: 'Arctic P12 PST', desc: 'F/P statik basınç.', price: 35.0 },
      { id: 'fan_del', name: 'Delta 4000RPM', desc: 'Server grade fan.', price: 45.0 },
    ],
  },
  psu: {
    title: 'POWER',
    items: [
      { id: 'psu_850', name: 'Corsair RM850x', desc: 'Tam modüler.', price: 149.0 },
      { id: 'psu_12', name: 'Supermicro 1200W', desc: '1+1 Yedekli.', price: 450.0 },
    ],
  },
  mobo: {
    title: 'MOBO',
    items: [
      { id: 'mb_pro', name: 'ASUS ProArt X670E', desc: 'Stabil VRM.', price: 479.0 },
      { id: 'mb_wrx', name: 'ASUS WRX80E', desc: 'Multi-GPU cluster.', price: 999.0 },
    ],
  },
  cpu: {
    title: 'CPU',
    items: [
      { id: 'cpu_79', name: 'AMD Ryzen 9 7950X', desc: '16 Core Compute.', price: 599.0 },
      { id: 'cpu_tr', name: 'Threadripper 7995WX', desc: '96 Core Workstation.', price: 9999.0 },
    ],
  },
  ram: {
    title: 'RAM',
    items: [
      { id: 'ram_32', name: '32GB DDR5 6000MHz', desc: 'Düşük CL.', price: 119.0 },
      { id: 'ram_25', name: '256GB DDR5 RDIMM', desc: 'In-memory cache.', price: 1250.0 },
    ],
  },
  storage: {
    title: 'STORAGE',
    items: [
      { id: 'st_2tb', name: '2TB Samsung 990 PRO', desc: 'Hızlı boot.', price: 169.0 },
      { id: 'st_opt', name: '1.6TB Optane U.2', desc: 'Sıfır latency ZIL.', price: 2499.0 },
    ],
  },
  gpu: {
    title: 'GPU',
    items: [
      { id: 'gpu_40', name: 'NVIDIA RTX 4090', desc: 'Local LLM.', price: 1599.0 },
      { id: 'gpu_a6', name: 'RTX 6000 Ada', desc: 'VRAM canavarı.', price: 6799.0 },
    ],
  },
  cooling: {
    title: 'COOLING',
    items: [
      { id: 'cool_d', name: 'Noctua NH-D15', desc: 'Pump failure riskine son.', price: 119.0 },
      { id: 'cool_l', name: 'Arctic LF3 360', desc: '300W+ TDP.', price: 139.0 },
    ],
  },
};
